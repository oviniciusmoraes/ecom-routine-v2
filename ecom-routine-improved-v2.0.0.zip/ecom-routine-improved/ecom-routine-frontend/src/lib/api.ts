import axios from 'axios';
import { useAuthStore } from '@/store/authStore';

// Create axios instance
const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid, logout user
      useAuthStore.getState().logout();
    }
    return Promise.reject(error);
  }
);

export default api;

// Helper function for API calls with better error handling
export const apiCall = async <T>(
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  url: string,
  data?: any,
  config?: any
): Promise<T> => {
  try {
    const response = await api.request({
      method,
      url,
      data,
      ...config,
    });

    if (response.data.success === false) {
      throw new Error(response.data.error || 'Erro na API');
    }

    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.response?.status === 404) {
        throw new Error('Recurso não encontrado');
      } else if (error.response?.status === 500) {
        throw new Error('Erro interno do servidor');
      } else if (error.code === 'ECONNABORTED') {
        throw new Error('Timeout na requisição');
      } else if (!error.response) {
        throw new Error('Erro de conexão com o servidor');
      }
    }
    
    throw error;
  }
};

// Specific API functions
export const authAPI = {
  login: (credentials: { username?: string; email?: string; password: string }) =>
    apiCall('POST', '/auth/login', credentials),
  
  register: (userData: { username: string; email: string; password: string; name?: string }) =>
    apiCall('POST', '/auth/register', userData),
  
  me: () => apiCall('GET', '/auth/me'),
  
  logout: () => apiCall('POST', '/auth/logout'),
};

export const marketplaceAPI = {
  getAll: (params?: Record<string, string>) => {
    const searchParams = new URLSearchParams(params);
    return apiCall('GET', `/marketplaces?${searchParams.toString()}`);
  },
  
  getById: (id: string) => apiCall('GET', `/marketplaces/${id}`),
  
  create: (data: any) => apiCall('POST', '/marketplaces', data),
  
  update: (id: string, data: any) => apiCall('PUT', `/marketplaces/${id}`, data),
  
  delete: (id: string) => apiCall('DELETE', `/marketplaces/${id}`),
  
  toggleFavorite: (id: string) => apiCall('POST', `/marketplaces/${id}/toggle-favorite`),
  
  toggleActive: (id: string) => apiCall('POST', `/marketplaces/${id}/toggle-active`),
};

export const routineAPI = {
  getAll: (params?: Record<string, string>) => {
    const searchParams = new URLSearchParams(params);
    return apiCall('GET', `/routines?${searchParams.toString()}`);
  },
  
  getById: (id: number) => apiCall('GET', `/routines/${id}`),
  
  create: (data: any) => apiCall('POST', '/routines', data),
  
  update: (id: number, data: any) => apiCall('PUT', `/routines/${id}`, data),
  
  delete: (id: number) => apiCall('DELETE', `/routines/${id}`),
  
  execute: (id: number) => apiCall('POST', `/routines/${id}/execute`),
  
  getStats: () => apiCall('GET', '/routines/stats'),
};

export const taskAPI = {
  getAll: (params?: Record<string, string>) => {
    const searchParams = new URLSearchParams(params);
    return apiCall('GET', `/tasks?${searchParams.toString()}`);
  },
  
  getById: (id: string) => apiCall('GET', `/tasks/${id}`),
  
  create: (data: any) => apiCall('POST', '/tasks', data),
  
  update: (id: string, data: any) => apiCall('PUT', `/tasks/${id}`, data),
  
  delete: (id: string) => apiCall('DELETE', `/tasks/${id}`),
  
  start: (id: string) => apiCall('POST', `/tasks/${id}/start`),
  
  complete: (id: string) => apiCall('POST', `/tasks/${id}/complete`),
  
  pause: (id: string) => apiCall('POST', `/tasks/${id}/pause`),
  
  getDaily: () => apiCall('GET', '/tasks/daily'),
  
  getStats: () => apiCall('GET', '/tasks/stats'),
};

