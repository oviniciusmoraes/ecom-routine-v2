import { useToast } from "@/hooks/use-toast";
import { CheckCircle, AlertCircle, AlertTriangle, Info, X } from "lucide-react";

export const useNotifications = () => {
  const { toast } = useToast();

  const showSuccess = (title: string, description?: string) => {
    toast({
      title,
      description,
      duration: 4000,
      className: "border-green-200 bg-green-50 text-green-900",
    });
  };

  const showError = (title: string, description?: string) => {
    toast({
      title,
      description,
      duration: 6000,
      variant: "destructive",
    });
  };

  const showWarning = (title: string, description?: string) => {
    toast({
      title,
      description,
      duration: 5000,
      className: "border-yellow-200 bg-yellow-50 text-yellow-900",
    });
  };

  const showInfo = (title: string, description?: string) => {
    toast({
      title,
      description,
      duration: 4000,
      className: "border-blue-200 bg-blue-50 text-blue-900",
    });
  };

  const showLoading = (title: string, description?: string) => {
    return toast({
      title,
      description,
      duration: Infinity, // Keep until manually dismissed
      className: "border-gray-200 bg-gray-50 text-gray-900",
    });
  };

  const showApiError = (error: any, defaultMessage = "Ocorreu um erro inesperado") => {
    const message = error?.response?.data?.error || 
                   error?.message || 
                   defaultMessage;
    
    showError("Erro", message);
  };

  const showValidationError = (errors: Record<string, string[]>) => {
    const firstError = Object.values(errors)[0]?.[0];
    if (firstError) {
      showError("Erro de validação", firstError);
    }
  };

  const showNetworkError = () => {
    showError(
      "Erro de conexão",
      "Verifique sua conexão com a internet e tente novamente."
    );
  };

  const showUnauthorizedError = () => {
    showError(
      "Acesso negado",
      "Sua sessão expirou. Faça login novamente."
    );
  };

  const showOperationSuccess = (operation: string, item?: string) => {
    const messages = {
      create: `${item || 'Item'} criado com sucesso`,
      update: `${item || 'Item'} atualizado com sucesso`,
      delete: `${item || 'Item'} removido com sucesso`,
      save: `${item || 'Dados'} salvos com sucesso`,
      copy: `${item || 'Item'} copiado com sucesso`,
      import: `${item || 'Dados'} importados com sucesso`,
      export: `${item || 'Dados'} exportados com sucesso`,
    };

    showSuccess(messages[operation] || `${operation} realizada com sucesso`);
  };

  const showOperationError = (operation: string, item?: string, error?: any) => {
    const messages = {
      create: `Erro ao criar ${item || 'item'}`,
      update: `Erro ao atualizar ${item || 'item'}`,
      delete: `Erro ao remover ${item || 'item'}`,
      save: `Erro ao salvar ${item || 'dados'}`,
      copy: `Erro ao copiar ${item || 'item'}`,
      import: `Erro ao importar ${item || 'dados'}`,
      export: `Erro ao exportar ${item || 'dados'}`,
      load: `Erro ao carregar ${item || 'dados'}`,
    };

    const title = messages[operation] || `Erro ao executar ${operation}`;
    const description = error?.message || "Tente novamente em alguns instantes.";
    
    showError(title, description);
  };

  return {
    showSuccess,
    showError,
    showWarning,
    showInfo,
    showLoading,
    showApiError,
    showValidationError,
    showNetworkError,
    showUnauthorizedError,
    showOperationSuccess,
    showOperationError,
  };
};

