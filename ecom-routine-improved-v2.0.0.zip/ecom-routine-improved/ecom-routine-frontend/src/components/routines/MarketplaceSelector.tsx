import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, Check, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

// Get marketplaces from localStorage or use defaults
const getMarketplaces = () => {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('marketplaces');
    if (stored) {
      return JSON.parse(stored);
    }
  }
  
  return [
    {
      id: "shopee-filial",
      name: "Shopee Filial",
      description: "Conta filial da Shopee",
      color: "#EE4D2D",
      type: "ecommerce",
      priority: "medium",
      tags: ["e-commerce", "mobile"],
      active: true,
      logoUrl: "🛍️"
    },
    {
      id: "shopee-matriz",
      name: "Shopee Matriz",
      description: "Conta principal da Shopee",
      color: "#EE4D2D",
      type: "ecommerce",
      priority: "high",
      tags: ["e-commerce", "principal"],
      active: true,
      logoUrl: "🛍️"
    },
    {
      id: "shein-filial",
      name: "Shein Filial",
      description: "Conta filial da Shein",
      color: "#000000",
      type: "ecommerce",
      priority: "medium",
      tags: ["moda", "internacional"],
      active: true,
      logoUrl: "👗"
    },
    {
      id: "mercadolivre-matriz",
      name: "Mercado Livre Matriz",
      description: "Conta principal do Mercado Livre",
      color: "#3483FA",
      type: "ecommerce",
      priority: "high",
      tags: ["e-commerce", "principal"],
      active: true,
      logoUrl: "🛒"
    },
    {
      id: "mercadolivre-variedades",
      name: "Mercado Livre Variedades",
      description: "Conta especializada em variedades",
      color: "#3483FA",
      type: "ecommerce",
      priority: "medium",
      tags: ["variedades"],
      active: true,
      logoUrl: "🛒"
    },
    {
      id: "mercadolivre-starjeans",
      name: "Mercado Livre Starjeans",
      description: "Conta especializada em jeans",
      color: "#3483FA",
      type: "ecommerce",
      priority: "medium",
      tags: ["moda", "especializada"],
      active: true,
      logoUrl: "🛒"
    },
    {
      id: "mercadolivre-virgem",
      name: "Mercado Livre Virgem",
      description: "Nova conta em desenvolvimento",
      color: "#3483FA",
      type: "ecommerce",
      priority: "low",
      tags: ["desenvolvimento"],
      active: false,
      logoUrl: "🛒"
    },
    {
      id: "amazon",
      name: "Amazon",
      description: "Marketplace internacional",
      color: "#FF9900",
      type: "ecommerce",
      priority: "high",
      tags: ["internacional", "premium"],
      active: true,
      logoUrl: "📦"
    },
    {
      id: "magalu",
      name: "Magalu",
      description: "Magazine Luiza marketplace",
      color: "#0F4C9B",
      type: "ecommerce",
      priority: "medium",
      tags: ["nacional", "varejo"],
      active: true,
      logoUrl: "🏪"
    },
    {
      id: "americanas",
      name: "Americanas",
      description: "Marketplace Americanas",
      color: "#E4002B",
      type: "ecommerce",
      priority: "medium",
      tags: ["nacional", "varejo"],
      active: false,
      logoUrl: "🏬"
    }
  ];
};

interface MarketplaceSelectorProps {
  selected: string;
  onSelect: (marketplace: string) => void;
}

export const MarketplaceSelector = ({ selected, onSelect }: MarketplaceSelectorProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const marketplaces = getMarketplaces();

  const filteredMarketplaces = marketplaces.filter(marketplace => {
    const matchesSearch = marketplace.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         marketplace.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || 
                         (statusFilter === "active" && marketplace.active) ||
                         (statusFilter === "inactive" && !marketplace.active);
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (active: boolean) => {
    return active 
      ? <Badge className="bg-success/10 text-success border-success/20">Ativo</Badge>
      : <Badge className="bg-muted/10 text-muted-foreground border-muted/20">Inativo</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar marketplace..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setStatusFilter("all")}
            className={cn(
              "px-3 py-1 text-sm rounded-full border",
              statusFilter === "all"
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-background border-border hover:bg-muted"
            )}
          >
            Todos
          </button>
          <button
            onClick={() => setStatusFilter("active")}
            className={cn(
              "px-3 py-1 text-sm rounded-full border",
              statusFilter === "active"
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-background border-border hover:bg-muted"
            )}
          >
            Ativos
          </button>
          <button
            onClick={() => setStatusFilter("inactive")}
            className={cn(
              "px-3 py-1 text-sm rounded-full border",
              statusFilter === "inactive"
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-background border-border hover:bg-muted"
            )}
          >
            Inativos
          </button>
        </div>
      </div>

      {/* Selected Marketplace */}
      {selected && (
        <div className="space-y-2">
          <Label className="text-sm font-medium">Marketplace Selecionado:</Label>
          <Card className="border-primary/50 bg-primary/5">
            <CardContent className="p-3">
              <div className="flex items-center gap-3">
                <div className="text-2xl">{marketplaces.find(m => m.id === selected)?.logoUrl}</div>
                <div>
                  <p className="font-medium text-foreground">
                    {marketplaces.find(m => m.id === selected)?.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {marketplaces.find(m => m.id === selected)?.description}
                  </p>
                </div>
                <div className="ml-auto">
                  <Check className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Marketplace Grid */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">Selecione um Marketplace:</Label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredMarketplaces.map((marketplace) => (
            <Card
              key={marketplace.id}
              className={cn(
                "cursor-pointer transition-all hover:shadow-md border-border/50",
                selected === marketplace.id
                  ? "ring-2 ring-primary bg-primary/5 border-primary/50"
                  : "hover:border-primary/20"
              )}
              onClick={() => onSelect(marketplace.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                    style={{ backgroundColor: marketplace.color }}
                  >
                    {marketplace.logoUrl || marketplace.name.slice(0, 2).toUpperCase()}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-foreground truncate">
                        {marketplace.name}
                      </h3>
                      {selected === marketplace.id && (
                        <Check className="h-4 w-4 text-primary flex-shrink-0" />
                      )}
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-1">
                      {marketplace.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      {getStatusBadge(marketplace.active)}
                      
                      {marketplace.tags && marketplace.tags.length > 0 && (
                        <div className="flex gap-1">
                          {marketplace.tags.slice(0, 2).map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {filteredMarketplaces.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Globe className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <h3 className="font-medium text-foreground mb-2">Nenhum marketplace encontrado</h3>
            <p className="text-sm text-muted-foreground">
              Tente ajustar os filtros de busca ou entre em contato com o administrador.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};