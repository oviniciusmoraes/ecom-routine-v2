import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface Routine {
  id: number;
  name: string;
  marketplace: string;
  marketplaceColor: string;
  nextExecution: string;
  status: string;
}

interface RoutineCalendarProps {
  routines: Routine[];
}

export const RoutineCalendar = ({ routines }: RoutineCalendarProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getRoutinesForDate = (date: Date | null) => {
    if (!date) return [];
    
    return routines.filter(routine => {
      const routineDate = new Date(routine.nextExecution);
      return (
        routineDate.getDate() === date.getDate() &&
        routineDate.getMonth() === date.getMonth() &&
        routineDate.getFullYear() === date.getFullYear()
      );
    });
  };

  const navigateMonth = (direction: "prev" | "next") => {
    const newDate = new Date(currentDate);
    if (direction === "prev") {
      newDate.setMonth(newDate.getMonth() - 1);
    } else {
      newDate.setMonth(newDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };

  const days = getDaysInMonth(currentDate);
  const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  
  const monthNames = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Calendário de Execuções
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium min-w-[120px] text-center">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </span>
            <Button variant="outline" size="sm" onClick={() => navigateMonth("next")}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-1 mb-4">
          {weekDays.map((day) => (
            <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
              {day}
            </div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {days.map((day, index) => {
            const dayRoutines = getRoutinesForDate(day);
            const isToday = day && 
              day.getDate() === new Date().getDate() &&
              day.getMonth() === new Date().getMonth() &&
              day.getFullYear() === new Date().getFullYear();
            
            return (
              <div
                key={index}
                className={cn(
                  "min-h-[100px] p-2 border border-border/50 rounded-lg",
                  day ? "bg-background hover:bg-muted/50 cursor-pointer" : "bg-muted/20",
                  isToday && "ring-2 ring-primary bg-primary/5"
                )}
              >
                {day && (
                  <>
                    <div className={cn(
                      "text-sm font-medium mb-2",
                      isToday ? "text-primary" : "text-foreground"
                    )}>
                      {day.getDate()}
                    </div>
                    <div className="space-y-1">
                      {dayRoutines.slice(0, 3).map((routine) => (
                        <div
                          key={routine.id}
                          className={cn(
                            "text-xs p-1 rounded text-white truncate",
                            routine.marketplaceColor
                          )}
                          title={routine.name}
                        >
                          {routine.name}
                        </div>
                      ))}
                      {dayRoutines.length > 3 && (
                        <div className="text-xs text-muted-foreground px-1">
                          +{dayRoutines.length - 3} mais
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Legend */}
        <div className="mt-6 pt-4 border-t border-border/50">
          <h4 className="text-sm font-medium mb-3">Marketplaces:</h4>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-shopee text-white">Shopee</Badge>
            <Badge className="bg-mercadolivre text-white">Mercado Livre</Badge>
            <Badge className="bg-shein text-white">Shein</Badge>
            <Badge className="bg-amazon text-white">Amazon</Badge>
            <Badge className="bg-magalu text-white">Magalu</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};