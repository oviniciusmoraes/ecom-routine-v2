import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Play, Pause, Edit, Copy, Archive, MoreHorizontal, Clock, User, Calendar, ListTodo } from "lucide-react";
import { cn } from "@/lib/utils";

interface RoutineCardProps {
  routine: {
    id: number;
    name: string;
    description: string;
    marketplace: string;
    marketplaceColor: string;
    frequency: string;
    nextExecution: string;
    responsible: string;
    status: string;
    tasks: number;
    estimatedTime: string;
  };
}

export const RoutineCard = ({ routine }: RoutineCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-success/10 text-success border-success/20";
      case "paused":
        return "bg-warning/10 text-warning border-warning/20";
      case "archived":
        return "bg-muted text-muted-foreground border-muted-foreground/20";
      default:
        return "bg-muted text-muted-foreground border-muted-foreground/20";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Ativo";
      case "paused":
        return "Pausado";
      case "archived":
        return "Arquivado";
      default:
        return status;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-3">
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                {routine.name}
              </h3>
              <Badge className={cn("text-xs", getStatusColor(routine.status))}>
                {getStatusLabel(routine.status)}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {routine.description}
            </p>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem className="gap-2">
                <Edit className="h-4 w-4" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2">
                <Copy className="h-4 w-4" />
                Duplicar
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2">
                {routine.status === "active" ? (
                  <>
                    <Pause className="h-4 w-4" />
                    Pausar
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    Ativar
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 text-destructive">
                <Archive className="h-4 w-4" />
                Arquivar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Marketplace Badge */}
        <div className="flex items-center gap-2">
          <div className={cn("w-3 h-3 rounded-full", routine.marketplaceColor)} />
          <span className="text-sm font-medium text-foreground">{routine.marketplace}</span>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>{routine.frequency}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{routine.estimatedTime}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <User className="h-4 w-4" />
            <span>{routine.responsible}</span>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <ListTodo className="h-4 w-4" />
            <span>{routine.tasks} tarefas</span>
          </div>
        </div>

        {/* Next Execution */}
        <div className="pt-2 border-t border-border/50">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Próxima execução:</span>
            <span className="text-xs font-medium text-foreground">
              {formatDate(routine.nextExecution)}
            </span>
          </div>
        </div>

        {/* Actions */}
        {routine.status === "active" && (
          <div className="flex gap-2 pt-2">
            <Button size="sm" variant="outline" className="flex-1 gap-2">
              <Play className="h-4 w-4" />
              Executar Agora
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};