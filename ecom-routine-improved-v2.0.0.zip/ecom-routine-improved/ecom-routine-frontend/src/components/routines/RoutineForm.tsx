import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { MarketplaceSelector } from "./MarketplaceSelector";
import { PeriodicityConfig } from "./PeriodicityConfig";
import { TaskEditor } from "./TaskEditor";
import { Save, X, ArrowLeft, ArrowRight } from "lucide-react";

interface RoutineFormProps {
  open: boolean;
  onClose: () => void;
  routine?: any;
}

export const RoutineForm = ({ open, onClose, routine }: RoutineFormProps) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    name: routine?.name || "",
    description: routine?.description || "",
    category: routine?.category || "",
    priority: routine?.priority || "medium",
    marketplace: routine?.marketplace || "",
    periodicity: routine?.periodicity || {},
    tasks: routine?.tasks || [],
    responsible: routine?.responsible || "",
    notifications: routine?.notifications || true,
  });

  const steps = [
    { id: 1, title: "Informações Básicas", description: "Nome, descrição e configurações gerais" },
    { id: 2, title: "Marketplace", description: "Selecione o marketplace da rotina" },
    { id: 3, title: "Periodicidade", description: "Configure quando executar" },
    { id: 4, title: "Tarefas", description: "Defina as tarefas da rotina" },
    { id: 5, title: "Configurações", description: "Responsáveis e notificações" },
    { id: 6, title: "Revisão", description: "Confirme todas as configurações" }
  ];

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSave = () => {
    // Aqui você implementaria a lógica de salvamento
    console.log("Saving routine:", formData);
    onClose();
  };

  const updateFormData = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="border-b pb-4">
          <DialogTitle className="text-xl">
            {routine ? "Editar Rotina" : "Nova Rotina"}
          </DialogTitle>
          
          {/* Progress Steps */}
          <div className="flex items-center justify-between mt-4">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                  ${currentStep >= step.id 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted text-muted-foreground'
                  }
                `}>
                  {step.id}
                </div>
                {index < steps.length - 1 && (
                  <div className={`
                    w-12 h-0.5 mx-2
                    ${currentStep > step.id ? 'bg-primary' : 'bg-muted'}
                  `} />
                )}
              </div>
            ))}
          </div>
          
          {/* Current Step Info */}
          <div className="text-center mt-4">
            <h3 className="font-medium text-foreground">{steps[currentStep - 1].title}</h3>
            <p className="text-sm text-muted-foreground">{steps[currentStep - 1].description}</p>
          </div>
        </DialogHeader>

        <div className="py-6">
          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Nome da Rotina *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => updateFormData("name", e.target.value)}
                  placeholder="Ex: Verificação Diária Shopee Filial"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => updateFormData("description", e.target.value)}
                  placeholder="Descreva o objetivo e contexto da rotina..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Categoria</Label>
                  <Select value={formData.category} onValueChange={(value) => updateFormData("category", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="operational">Operacional</SelectItem>
                      <SelectItem value="strategic">Estratégica</SelectItem>
                      <SelectItem value="maintenance">Manutenção</SelectItem>
                      <SelectItem value="analysis">Análise</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Prioridade</Label>
                  <RadioGroup value={formData.priority} onValueChange={(value) => updateFormData("priority", value)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="low" id="low" />
                      <Label htmlFor="low" className="text-sm">Baixa</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="text-sm">Média</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="high" id="high" />
                      <Label htmlFor="high" className="text-sm">Alta</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="critical" id="critical" />
                      <Label htmlFor="critical" className="text-sm">Crítica</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Marketplace Selection */}
          {currentStep === 2 && (
            <MarketplaceSelector
              selected={formData.marketplace}
              onSelect={(marketplace) => updateFormData("marketplace", marketplace)}
            />
          )}

          {/* Step 3: Periodicity Configuration */}
          {currentStep === 3 && (
            <PeriodicityConfig
              config={formData.periodicity}
              onChange={(config) => updateFormData("periodicity", config)}
            />
          )}

          {/* Step 4: Task Editor */}
          {currentStep === 4 && (
            <TaskEditor
              tasks={formData.tasks}
              onChange={(tasks) => updateFormData("tasks", tasks)}
            />
          )}

          {/* Step 5: Advanced Settings */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="responsible">Responsável Principal</Label>
                <Select value={formData.responsible} onValueChange={(value) => updateFormData("responsible", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o responsável" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="joao">João Silva</SelectItem>
                    <SelectItem value="maria">Maria Santos</SelectItem>
                    <SelectItem value="carlos">Carlos Lima</SelectItem>
                    <SelectItem value="ana">Ana Costa</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                <Label>Configurações de Notificação</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="notifications"
                      checked={formData.notifications}
                      onCheckedChange={(checked) => updateFormData("notifications", checked)}
                    />
                    <Label htmlFor="notifications" className="text-sm">
                      Receber notificações da rotina
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 6: Review */}
          {currentStep === 6 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Resumo da Rotina</CardTitle>
                  <CardDescription>Revise todas as configurações antes de salvar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="font-medium">Nome:</Label>
                    <p className="text-sm text-muted-foreground">{formData.name}</p>
                  </div>
                  <div>
                    <Label className="font-medium">Marketplace:</Label>
                    <p className="text-sm text-muted-foreground">{formData.marketplace}</p>
                  </div>
                  <div>
                    <Label className="font-medium">Categoria:</Label>
                    <Badge variant="secondary">{formData.category}</Badge>
                  </div>
                  <div>
                    <Label className="font-medium">Prioridade:</Label>
                    <Badge variant={formData.priority === "high" ? "destructive" : "default"}>
                      {formData.priority}
                    </Badge>
                  </div>
                  <div>
                    <Label className="font-medium">Tarefas:</Label>
                    <p className="text-sm text-muted-foreground">{formData.tasks.length} tarefas configuradas</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex justify-between items-center pt-4 border-t">
          <Button variant="outline" onClick={onClose} className="gap-2">
            <X className="h-4 w-4" />
            Cancelar
          </Button>

          <div className="flex gap-2">
            {currentStep > 1 && (
              <Button variant="outline" onClick={handlePrev} className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Anterior
              </Button>
            )}
            
            {currentStep < steps.length ? (
              <Button onClick={handleNext} className="gap-2">
                Próximo
                <ArrowRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button onClick={handleSave} className="gap-2">
                <Save className="h-4 w-4" />
                Salvar Rotina
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};