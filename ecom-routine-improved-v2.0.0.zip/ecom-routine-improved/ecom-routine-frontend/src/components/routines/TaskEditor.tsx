import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, GripVertical, Clock, Link, Target } from "lucide-react";
import { cn } from "@/lib/utils";

interface Task {
  id: string;
  title: string;
  description: string;
  estimatedTime: number;
  urls: string[];
  criteria: string;
  order: number;
}

interface TaskEditorProps {
  tasks: Task[];
  onChange: (tasks: Task[]) => void;
}

const taskTemplates = [
  {
    id: "metrics-analysis",
    title: "Análise de Métricas",
    description: "Verificar dashboard de métricas e identificar anomalias",
    estimatedTime: 15,
    criteria: "Todas as métricas dentro dos parâmetros normais",
    category: "Análise"
  },
  {
    id: "inventory-check",
    title: "Verificação de Estoque",
    description: "Conferir níveis de estoque e produtos em falta",
    estimatedTime: 20,
    criteria: "Lista de produtos com estoque baixo atualizada",
    category: "Operacional"
  },
  {
    id: "order-processing",
    title: "Processamento de Pedidos",
    description: "Verificar e processar pedidos pendentes",
    estimatedTime: 30,
    criteria: "Todos os pedidos processados sem atraso",
    category: "Operacional"
  },
  {
    id: "campaign-review",
    title: "Revisão de Campanhas",
    description: "Analisar performance de campanhas de marketing",
    estimatedTime: 25,
    criteria: "Relatório de performance gerado",
    category: "Marketing"
  }
];

export const TaskEditor = ({ tasks, onChange }: TaskEditorProps) => {
  const [showTemplates, setShowTemplates] = useState(false);

  const addTask = (template?: any) => {
    const newTask: Task = {
      id: Date.now().toString(),
      title: template?.title || "",
      description: template?.description || "",
      estimatedTime: template?.estimatedTime || 15,
      urls: [],
      criteria: template?.criteria || "",
      order: tasks.length + 1
    };
    onChange([...tasks, newTask]);
    setShowTemplates(false);
  };

  const updateTask = (taskId: string, field: string, value: any) => {
    const updatedTasks = tasks.map(task =>
      task.id === taskId ? { ...task, [field]: value } : task
    );
    onChange(updatedTasks);
  };

  const removeTask = (taskId: string) => {
    const updatedTasks = tasks.filter(task => task.id !== taskId);
    onChange(updatedTasks);
  };

  const addUrl = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      updateTask(taskId, "urls", [...task.urls, ""]);
    }
  };

  const updateUrl = (taskId: string, urlIndex: number, value: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      const newUrls = [...task.urls];
      newUrls[urlIndex] = value;
      updateTask(taskId, "urls", newUrls);
    }
  };

  const removeUrl = (taskId: string, urlIndex: number) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      const newUrls = task.urls.filter((_, index) => index !== urlIndex);
      updateTask(taskId, "urls", newUrls);
    }
  };

  const getTotalEstimatedTime = () => {
    return tasks.reduce((total, task) => total + task.estimatedTime, 0);
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes}min`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
  };

  return (
    <div className="space-y-6">
      {/* Header with Summary */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-foreground">Tarefas da Rotina</h3>
          <p className="text-sm text-muted-foreground">
            {tasks.length} tarefa(s) • Tempo estimado total: {formatTime(getTotalEstimatedTime())}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowTemplates(!showTemplates)}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            Templates
          </Button>
          <Button onClick={() => addTask()} className="gap-2">
            <Plus className="h-4 w-4" />
            Nova Tarefa
          </Button>
        </div>
      </div>

      {/* Templates Panel */}
      {showTemplates && (
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="text-base">Templates de Tarefas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {taskTemplates.map((template) => (
                <Card 
                  key={template.id}
                  className="cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => addTask(template)}
                >
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-sm">{template.title}</h4>
                      <Badge variant="secondary" className="text-xs">
                        {template.category}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                      {template.description}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {formatTime(template.estimatedTime)}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tasks List */}
      <div className="space-y-4">
        {tasks.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Target className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <h3 className="font-medium text-foreground mb-2">Nenhuma tarefa adicionada</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Adicione tarefas para compor sua rotina
              </p>
              <Button onClick={() => addTask()} className="gap-2">
                <Plus className="h-4 w-4" />
                Adicionar Primeira Tarefa
              </Button>
            </CardContent>
          </Card>
        ) : (
          tasks.map((task, index) => (
            <Card key={task.id} className="group">
              <CardHeader className="pb-3">
                <div className="flex items-start gap-3">
                  <div className="flex items-center gap-2 mt-1">
                    <GripVertical className="h-4 w-4 text-muted-foreground cursor-move" />
                    <span className="text-sm font-medium text-muted-foreground">
                      {index + 1}
                    </span>
                  </div>
                  
                  <div className="flex-1 space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor={`task-title-${task.id}`}>Título da Tarefa *</Label>
                      <Input
                        id={`task-title-${task.id}`}
                        value={task.title}
                        onChange={(e) => updateTask(task.id, "title", e.target.value)}
                        placeholder="Nome da tarefa..."
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`task-description-${task.id}`}>Descrição</Label>
                      <Textarea
                        id={`task-description-${task.id}`}
                        value={task.description}
                        onChange={(e) => updateTask(task.id, "description", e.target.value)}
                        placeholder="Descreva o que deve ser feito..."
                        rows={2}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`task-time-${task.id}`}>Tempo Estimado (minutos)</Label>
                        <Input
                          id={`task-time-${task.id}`}
                          type="number"
                          min="1"
                          value={task.estimatedTime}
                          onChange={(e) => updateTask(task.id, "estimatedTime", parseInt(e.target.value) || 15)}
                        />
                      </div>

                      <div className="flex items-end">
                        <div className="text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 inline mr-1" />
                          {formatTime(task.estimatedTime)}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`task-criteria-${task.id}`}>Critérios de Conclusão</Label>
                      <Textarea
                        id={`task-criteria-${task.id}`}
                        value={task.criteria}
                        onChange={(e) => updateTask(task.id, "criteria", e.target.value)}
                        placeholder="Como saber que a tarefa foi concluída com sucesso..."
                        rows={2}
                      />
                    </div>

                    {/* URLs Section */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label>URLs de Referência</Label>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => addUrl(task.id)}
                          className="gap-2"
                        >
                          <Link className="h-4 w-4" />
                          Adicionar URL
                        </Button>
                      </div>
                      
                      {task.urls.map((url, urlIndex) => (
                        <div key={urlIndex} className="flex gap-2">
                          <Input
                            value={url}
                            onChange={(e) => updateUrl(task.id, urlIndex, e.target.value)}
                            placeholder="https://..."
                            className="flex-1"
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeUrl(task.id, urlIndex)}
                            className="px-3"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeTask(task.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
            </Card>
          ))
        )}
      </div>

      {/* Summary */}
      {tasks.length > 0 && (
        <Card className="border-success/20 bg-success/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-success" />
                <span className="text-sm font-medium text-success">
                  Resumo da Rotina
                </span>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>{tasks.length} tarefa(s)</span>
                <span>•</span>
                <span>Tempo total: {formatTime(getTotalEstimatedTime())}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};