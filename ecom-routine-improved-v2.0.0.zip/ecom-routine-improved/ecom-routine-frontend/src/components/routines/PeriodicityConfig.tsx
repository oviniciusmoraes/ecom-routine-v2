import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Repeat } from "lucide-react";
import { cn } from "@/lib/utils";

interface PeriodicityConfigProps {
  config: any;
  onChange: (config: any) => void;
}

export const PeriodicityConfig = ({ config, onChange }: PeriodicityConfigProps) => {
  const [periodicityType, setPeriodicityType] = useState(config.type || "daily");
  const [dailyConfig, setDailyConfig] = useState(config.daily || {
    frequency: "everyday",
    time: "09:00",
    interval: 1
  });
  const [weeklyConfig, setWeeklyConfig] = useState(config.weekly || {
    days: [],
    time: "09:00"
  });
  const [monthlyConfig, setMonthlyConfig] = useState(config.monthly || {
    type: "specific-day",
    day: 1,
    time: "09:00"
  });

  const updateConfig = (type: string, typeConfig: any) => {
    const newConfig = {
      type,
      [type]: typeConfig
    };
    onChange(newConfig);
  };

  const weekDays = [
    { id: "monday", label: "Segunda", short: "Seg" },
    { id: "tuesday", label: "Terça", short: "Ter" },
    { id: "wednesday", label: "Quarta", short: "Qua" },
    { id: "thursday", label: "Quinta", short: "Qui" },
    { id: "friday", label: "Sexta", short: "Sex" },
    { id: "saturday", label: "Sábado", short: "Sáb" },
    { id: "sunday", label: "Domingo", short: "Dom" }
  ];

  const getPreviewText = () => {
    switch (periodicityType) {
      case "daily":
        if (dailyConfig.frequency === "everyday") {
          return `Todos os dias às ${dailyConfig.time}`;
        } else if (dailyConfig.frequency === "weekdays") {
          return `Dias úteis (Seg-Sex) às ${dailyConfig.time}`;
        } else if (dailyConfig.frequency === "interval") {
          return `A cada ${dailyConfig.interval} dia(s) às ${dailyConfig.time}`;
        }
        break;
      case "weekly":
        const selectedDays = weekDays.filter(day => weeklyConfig.days.includes(day.id));
        if (selectedDays.length === 0) return "Selecione pelo menos um dia";
        return `${selectedDays.map(d => d.short).join(", ")} às ${weeklyConfig.time}`;
      case "monthly":
        if (monthlyConfig.type === "specific-day") {
          return `Todo dia ${monthlyConfig.day} às ${monthlyConfig.time}`;
        }
        break;
      default:
        return "Configure a periodicidade";
    }
  };

  return (
    <div className="space-y-6">
      {/* Preview */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">Preview:</span>
            <span className="text-sm text-foreground">{getPreviewText()}</span>
          </div>
        </CardContent>
      </Card>

      {/* Periodicity Type Selection */}
      <div className="space-y-4">
        <Label className="text-base font-medium">Tipo de Periodicidade</Label>
        <RadioGroup 
          value={periodicityType} 
          onValueChange={(value) => {
            setPeriodicityType(value);
            updateConfig(value, value === "daily" ? dailyConfig : value === "weekly" ? weeklyConfig : monthlyConfig);
          }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          <Card className={cn(
            "cursor-pointer transition-all",
            periodicityType === "daily" ? "ring-2 ring-primary bg-primary/5" : "hover:bg-muted/50"
          )}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="daily" id="daily" />
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <Label htmlFor="daily" className="cursor-pointer">Diária</Label>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-1 ml-6">
                Execução todos os dias ou dias específicos
              </p>
            </CardContent>
          </Card>

          <Card className={cn(
            "cursor-pointer transition-all",
            periodicityType === "weekly" ? "ring-2 ring-primary bg-primary/5" : "hover:bg-muted/50"
          )}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="weekly" id="weekly" />
                <div className="flex items-center gap-2">
                  <Repeat className="h-4 w-4" />
                  <Label htmlFor="weekly" className="cursor-pointer">Semanal</Label>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-1 ml-6">
                Execução em dias específicos da semana
              </p>
            </CardContent>
          </Card>

          <Card className={cn(
            "cursor-pointer transition-all",
            periodicityType === "monthly" ? "ring-2 ring-primary bg-primary/5" : "hover:bg-muted/50"
          )}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="monthly" id="monthly" />
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <Label htmlFor="monthly" className="cursor-pointer">Mensal</Label>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-1 ml-6">
                Execução uma vez por mês
              </p>
            </CardContent>
          </Card>
        </RadioGroup>
      </div>

      {/* Daily Configuration */}
      {periodicityType === "daily" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Configuração Diária</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Label>Frequência</Label>
              <RadioGroup 
                value={dailyConfig.frequency} 
                onValueChange={(value) => {
                  const newConfig = { ...dailyConfig, frequency: value };
                  setDailyConfig(newConfig);
                  updateConfig("daily", newConfig);
                }}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="everyday" id="everyday" />
                  <Label htmlFor="everyday">Todos os dias (incluindo fins de semana)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="weekdays" id="weekdays" />
                  <Label htmlFor="weekdays">Apenas dias úteis (Segunda a Sexta)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="interval" id="interval" />
                  <Label htmlFor="interval">A cada X dias</Label>
                </div>
              </RadioGroup>
            </div>

            {dailyConfig.frequency === "interval" && (
              <div className="flex items-center gap-2">
                <Label>A cada</Label>
                <Input
                  type="number"
                  min="1"
                  max="30"
                  value={dailyConfig.interval}
                  onChange={(e) => {
                    const newConfig = { ...dailyConfig, interval: parseInt(e.target.value) || 1 };
                    setDailyConfig(newConfig);
                    updateConfig("daily", newConfig);
                  }}
                  className="w-20"
                />
                <Label>dia(s)</Label>
              </div>
            )}

            <div className="space-y-2">
              <Label>Horário de Execução</Label>
              <Input
                type="time"
                value={dailyConfig.time}
                onChange={(e) => {
                  const newConfig = { ...dailyConfig, time: e.target.value };
                  setDailyConfig(newConfig);
                  updateConfig("daily", newConfig);
                }}
                className="w-40"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Weekly Configuration */}
      {periodicityType === "weekly" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Configuração Semanal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Label>Dias da Semana</Label>
              <div className="grid grid-cols-7 gap-2">
                {weekDays.map((day) => (
                  <Card
                    key={day.id}
                    className={cn(
                      "cursor-pointer transition-all text-center",
                      weeklyConfig.days.includes(day.id)
                        ? "ring-2 ring-primary bg-primary/10"
                        : "hover:bg-muted/50"
                    )}
                    onClick={() => {
                      const newDays = weeklyConfig.days.includes(day.id)
                        ? weeklyConfig.days.filter((d: string) => d !== day.id)
                        : [...weeklyConfig.days, day.id];
                      const newConfig = { ...weeklyConfig, days: newDays };
                      setWeeklyConfig(newConfig);
                      updateConfig("weekly", newConfig);
                    }}
                  >
                    <CardContent className="p-3">
                      <div className="text-xs font-medium">{day.short}</div>
                      <div className="text-xs text-muted-foreground">{day.label}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {weeklyConfig.days.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {weeklyConfig.days.map((dayId: string) => {
                    const day = weekDays.find(d => d.id === dayId);
                    return day ? (
                      <Badge key={dayId} variant="secondary">
                        {day.label}
                      </Badge>
                    ) : null;
                  })}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Horário de Execução</Label>
              <Input
                type="time"
                value={weeklyConfig.time}
                onChange={(e) => {
                  const newConfig = { ...weeklyConfig, time: e.target.value };
                  setWeeklyConfig(newConfig);
                  updateConfig("weekly", newConfig);
                }}
                className="w-40"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Monthly Configuration */}
      {periodicityType === "monthly" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Configuração Mensal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Label>Tipo de Execução</Label>
              <RadioGroup 
                value={monthlyConfig.type} 
                onValueChange={(value) => {
                  const newConfig = { ...monthlyConfig, type: value };
                  setMonthlyConfig(newConfig);
                  updateConfig("monthly", newConfig);
                }}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="specific-day" id="specific-day" />
                  <Label htmlFor="specific-day">Dia específico do mês</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="first-workday" id="first-workday" />
                  <Label htmlFor="first-workday">Primeiro dia útil do mês</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="last-workday" id="last-workday" />
                  <Label htmlFor="last-workday">Último dia útil do mês</Label>
                </div>
              </RadioGroup>
            </div>

            {monthlyConfig.type === "specific-day" && (
              <div className="flex items-center gap-2">
                <Label>Dia</Label>
                <Select 
                  value={monthlyConfig.day.toString()} 
                  onValueChange={(value) => {
                    const newConfig = { ...monthlyConfig, day: parseInt(value) };
                    setMonthlyConfig(newConfig);
                    updateConfig("monthly", newConfig);
                  }}
                >
                  <SelectTrigger className="w-20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                      <SelectItem key={day} value={day.toString()}>
                        {day}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label>Horário de Execução</Label>
              <Input
                type="time"
                value={monthlyConfig.time}
                onChange={(e) => {
                  const newConfig = { ...monthlyConfig, time: e.target.value };
                  setMonthlyConfig(newConfig);
                  updateConfig("monthly", newConfig);
                }}
                className="w-40"
              />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};