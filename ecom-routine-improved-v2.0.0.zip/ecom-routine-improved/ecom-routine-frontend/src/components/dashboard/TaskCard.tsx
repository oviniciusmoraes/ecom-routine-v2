import { Calendar, User, Clock, AlertCircle, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface TaskCardProps {
  id: string;
  title: string;
  description?: string;
  status: "todo" | "in-progress" | "completed" | "overdue";
  priority: "low" | "medium" | "high" | "critical";
  marketplace: "mercado-livre" | "shopee" | "shein" | "amazon";
  assignee: {
    name: string;
    avatar?: string;
    initials: string;
  };
  dueDate: string;
  completedAt?: string;
  category?: string;
}

const statusConfig = {
  todo: {
    label: "A Fazer",
    variant: "secondary" as const,
    icon: Clock,
    color: "text-muted-foreground"
  },
  "in-progress": {
    label: "Em Progresso",
    variant: "default" as const,
    icon: AlertCircle,
    color: "text-info"
  },
  completed: {
    label: "Concluído",
    variant: "outline" as const,
    icon: CheckCircle2,
    color: "text-success"
  },
  overdue: {
    label: "Atrasado",
    variant: "destructive" as const,
    icon: AlertCircle,
    color: "text-destructive"
  }
};

const priorityConfig = {
  low: { label: "Baixa", color: "border-l-muted-foreground" },
  medium: { label: "Média", color: "border-l-warning" },
  high: { label: "Alta", color: "border-l-marketplace-shopee" },
  critical: { label: "Crítica", color: "border-l-destructive" }
};

const marketplaceConfig = {
  "mercado-livre": { label: "Mercado Livre", color: "bg-marketplace-ml" },
  shopee: { label: "Shopee", color: "bg-marketplace-shopee" },
  shein: { label: "Shein", color: "bg-marketplace-shein" },
  amazon: { label: "Amazon", color: "bg-marketplace-amazon" }
};

const TaskCard = ({
  title,
  description,
  status,
  priority,
  marketplace,
  assignee,
  dueDate,
  category
}: TaskCardProps) => {
  const StatusIcon = statusConfig[status].icon;
  
  return (
    <Card className={cn(
      "group hover:shadow-lg transition-all duration-300 border-l-4 animate-fade-in",
      priorityConfig[priority].color
    )}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between space-x-2">
          <div className="flex-1 space-y-1">
            <h3 className="font-semibold text-sm leading-none group-hover:text-primary transition-colors">
              {title}
            </h3>
            {description && (
              <p className="text-xs text-muted-foreground line-clamp-2">
                {description}
              </p>
            )}
          </div>
          <Badge 
            variant={statusConfig[status].variant}
            className="shrink-0"
          >
            <StatusIcon className="mr-1 h-3 w-3" />
            {statusConfig[status].label}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
            <Calendar className="h-3 w-3" />
            <span>{dueDate}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Marketplace badge */}
            <div className={cn(
              "h-2 w-2 rounded-full",
              marketplaceConfig[marketplace].color
            )} />
            
            {/* Assignee */}
            <Avatar className="h-6 w-6">
              <AvatarImage src={assignee.avatar} />
              <AvatarFallback className="text-xs">
                {assignee.initials}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-3 gap-2">
          <div className="flex items-center space-x-1">
            <Badge variant="outline" className="text-xs">
              {marketplaceConfig[marketplace].label}
            </Badge>
            {category && (
              <Badge variant="secondary" className="text-xs">
                {category}
              </Badge>
            )}
          </div>
          
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs">
            Ver Detalhes
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TaskCard;