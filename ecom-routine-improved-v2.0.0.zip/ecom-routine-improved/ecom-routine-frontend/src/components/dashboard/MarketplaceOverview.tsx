import { TrendingUp, TrendingDown, Package, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
interface MarketplaceData {
  id: string;
  name: string;
  logo: string;
  color: string;
  activeTasks: number;
  completedTasks: number;
  totalTasks: number;
  revenue: string;
  revenueChange: number;
  status: "healthy" | "warning" | "critical";
  lastSync: string;
}
const marketplaces: MarketplaceData[] = [{
  id: "mercado-livre",
  name: "Mercado Livre",
  logo: "ML",
  color: "bg-marketplace-ml",
  activeTasks: 8,
  completedTasks: 24,
  totalTasks: 32,
  revenue: "R$ 45.230",
  revenueChange: 12.5,
  status: "healthy",
  lastSync: "2 min atrás"
}, {
  id: "shopee",
  name: "Shopee",
  logo: "SP",
  color: "bg-marketplace-shopee",
  activeTasks: 5,
  completedTasks: 18,
  totalTasks: 23,
  revenue: "R$ 28.450",
  revenueChange: -3.2,
  status: "warning",
  lastSync: "5 min atrás"
}, {
  id: "shein",
  name: "Shein",
  logo: "SH",
  color: "bg-marketplace-shein",
  activeTasks: 12,
  completedTasks: 15,
  totalTasks: 27,
  revenue: "R$ 33.120",
  revenueChange: 8.1,
  status: "critical",
  lastSync: "15 min atrás"
}, {
  id: "amazon",
  name: "Amazon",
  logo: "AM",
  color: "bg-marketplace-amazon",
  activeTasks: 3,
  completedTasks: 21,
  totalTasks: 24,
  revenue: "R$ 52.890",
  revenueChange: 15.7,
  status: "healthy",
  lastSync: "1 min atrás"
}];
const MarketplaceOverview = () => {
  return <Card className="animate-fade-in shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Visão Geral dos Marketplaces
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {marketplaces.map(marketplace => {
          const completionRate = marketplace.completedTasks / marketplace.totalTasks * 100;
          return <div key={marketplace.id} className="flex items-center justify-between p-4 rounded-lg border bg-card hover:shadow-md transition-all duration-200">
                {/* Marketplace Info */}
                <div className="flex items-center space-x-3">
                  <div className={cn("flex h-10 w-10 items-center justify-center rounded-lg text-white font-bold", marketplace.color)}>
                    {marketplace.logo}
                  </div>
                  <div>
                    <h4 className="font-medium">{marketplace.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      Sincronizado {marketplace.lastSync}
                    </p>
                  </div>
                </div>

                {/* Tasks Progress */}
                <div className="flex-1 max-w-xs mx-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-muted-foreground">Tarefas</span>
                    <span className="text-sm font-medium">
                      {marketplace.completedTasks}/{marketplace.totalTasks}
                    </span>
                  </div>
                  <Progress value={completionRate} className="h-2" />
                </div>

                {/* Revenue & Status */}
                <div className="text-right space-y-1">
                  
                  
                  <div className="flex items-center space-x-1">
                    
                    {marketplace.activeTasks > 0 && <Badge variant="outline" className="text-xs">
                        {marketplace.activeTasks} ativas
                      </Badge>}
                  </div>
                </div>
              </div>;
        })}
        </div>
      </CardContent>
    </Card>;
};
export default MarketplaceOverview;