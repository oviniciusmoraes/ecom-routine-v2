import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: "increase" | "decrease" | "neutral";
  icon: LucideIcon;
  variant?: "default" | "success" | "warning" | "info";
  className?: string;
}

const StatsCard = ({
  title,
  value,
  change,
  changeType = "neutral",
  icon: Icon,
  variant = "default",
  className
}: StatsCardProps) => {
  const variants = {
    default: "border-border",
    success: "border-success/20 bg-success-light/30",
    warning: "border-warning/20 bg-warning-light/30", 
    info: "border-info/20 bg-info-light/30"
  };

  const iconVariants = {
    default: "text-primary",
    success: "text-success",
    warning: "text-warning",
    info: "text-info"
  };

  return (
    <Card className={cn("animate-fade-in shadow-card", variants[variant], className)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between space-y-0">
          <div className="flex-1">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <div className="flex items-center space-x-2 mt-2">
              <h3 className="text-2xl font-bold tracking-tight">{value}</h3>
              {change && (
                <span
                  className={cn(
                    "text-sm font-medium",
                    changeType === "increase" && "text-success",
                    changeType === "decrease" && "text-destructive",
                    changeType === "neutral" && "text-muted-foreground"
                  )}
                >
                  {change}
                </span>
              )}
            </div>
          </div>
          <div className={cn(
            "flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10",
            iconVariants[variant]
          )}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StatsCard;