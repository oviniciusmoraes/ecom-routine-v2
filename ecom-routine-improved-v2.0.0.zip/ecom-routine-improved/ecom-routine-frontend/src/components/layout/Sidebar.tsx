import { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  CheckSquare,
  Calendar,
  Store,
  BarChart3,
  Users,
  Settings,
  Package,
  Repeat,
  TrendingUp,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navigationItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
    badge: null,
  },
  {
    title: "Tarefas Diárias",
    href: "/tasks",
    icon: CheckSquare,
    badge: "12",
  },
  {
    title: "Rotinas",
    href: "/routines",
    icon: Repeat,
    badge: null,
  },
  {
    title: "Marketplaces",
    href: "/marketplaces",
    icon: Store,
    badge: "4",
  },
  {
    title: "Calendário",
    href: "/calendar",
    icon: Calendar,
    badge: null,
  },
];

const teamItems = [
  {
    title: "Equipe",
    href: "/team",
    icon: Users,
    badge: null,
  },
  {
    title: "Performance",
    href: "/performance",
    icon: TrendingUp,
    badge: null,
  },
  {
    title: "Configurações",
    href: "/settings",
    icon: Settings,
    badge: null,
  },
];

const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-background/50 backdrop-blur-sm md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-50 h-full w-64 transform border-r bg-card transition-transform duration-300 ease-in-out md:static md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Header */}
        <div className="flex h-16 items-center justify-between border-b px-4">
          <div className="flex items-center space-x-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary">
              <span className="text-sm font-bold text-primary-foreground">ER</span>
            </div>
            <span className="font-bold">E-commerce Routine</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 p-4">
          {/* Main Navigation */}
          <div className="space-y-1">
            <h3 className="mb-2 px-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Principal
            </h3>
            {navigationItems.map((item) => (
              <NavLink
                key={item.href}
                to={item.href}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-muted",
                    isActive
                      ? "bg-primary/10 text-primary shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  )
                }
                onClick={() => {
                  // Close mobile sidebar when navigating
                  if (window.innerWidth < 768) {
                    onClose();
                  }
                }}
              >
                <item.icon className="h-4 w-4" />
                <span className="flex-1">{item.title}</span>
                {item.badge && (
                  <Badge variant="secondary" className="ml-auto">
                    {item.badge}
                  </Badge>
                )}
              </NavLink>
            ))}
          </div>

          {/* Team & Settings */}
          <div className="space-y-1 pt-4">
            <h3 className="mb-2 px-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Equipe & Config
            </h3>
            {teamItems.map((item) => (
              <NavLink
                key={item.href}
                to={item.href}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all hover:bg-muted",
                    isActive
                      ? "bg-primary/10 text-primary shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  )
                }
                onClick={() => {
                  if (window.innerWidth < 768) {
                    onClose();
                  }
                }}
              >
                <item.icon className="h-4 w-4" />
                <span className="flex-1">{item.title}</span>
                {item.badge && (
                  <Badge variant="secondary" className="ml-auto">
                    {item.badge}
                  </Badge>
                )}
              </NavLink>
            ))}
          </div>
        </nav>

        {/* Footer */}
        <div className="border-t p-4">
          <div className="rounded-lg bg-primary-light p-3">
            <h4 className="text-sm font-medium text-primary">
              Upgrade para Pro
            </h4>
            <p className="text-xs text-primary/80 mt-1">
              Automações avançadas e relatórios personalizados
            </p>
            <Button size="sm" className="mt-2 w-full" variant="default">
              Conhecer Planos
            </Button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;