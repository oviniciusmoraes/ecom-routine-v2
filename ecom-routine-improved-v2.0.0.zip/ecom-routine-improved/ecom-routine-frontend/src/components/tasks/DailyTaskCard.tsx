import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Play, Pause, CheckCircle, Clock, ExternalLink, AlertCircle, RotateCcw } from "lucide-react";
import { Task, TaskStatus } from "@/pages/DailyTasks";
import { cn } from "@/lib/utils";

interface DailyTaskCardProps {
  task: Task;
  onStatusChange: (taskId: string, status: TaskStatus) => void;
}

export const DailyTaskCard = ({ task, onStatusChange }: DailyTaskCardProps) => {
  const [showUrls, setShowUrls] = useState(false);

  const getStatusIcon = () => {
    switch (task.status) {
      case "not_started":
        return <div className="h-6 w-6 rounded-full border-2 border-muted-foreground flex items-center justify-center">
          <Play className="h-3 w-3 text-muted-foreground" />
        </div>;
      case "in_progress":
        return <div className="h-6 w-6 rounded-full bg-warning flex items-center justify-center">
          <Clock className="h-3 w-3 text-warning-foreground" />
        </div>;
      case "completed":
        return <CheckCircle className="h-6 w-6 text-success fill-success/20" />;
      case "overdue":
        return <AlertCircle className="h-6 w-6 text-destructive fill-destructive/20" />;
    }
  };

  const getElapsedTime = () => {
    if (!task.startedAt) return null;
    const elapsed = Math.floor((Date.now() - task.startedAt.getTime()) / 1000 / 60);
    return `${elapsed}min`;
  };

  const getCompletedTime = () => {
    if (!task.completedAt) return null;
    return task.completedAt.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getPriorityColor = () => {
    switch (task.priority) {
      case "critical": return "border-l-destructive bg-destructive/5";
      case "high": return "border-l-warning bg-warning/5";
      case "medium": return "border-l-primary bg-primary/5";
      case "low": return "border-l-muted-foreground bg-muted/5";
    }
  };

  const renderActionButtons = () => {
    switch (task.status) {
      case "not_started":
        return (
          <Button 
            onClick={() => onStatusChange(task.id, "in_progress")}
            className="gap-2"
          >
            <Play className="h-4 w-4" />
            Iniciar
          </Button>
        );
      case "in_progress":
        return (
          <div className="flex gap-2">
            <Button 
              variant="outline"
              onClick={() => onStatusChange(task.id, "not_started")}
              className="gap-2"
            >
              <Pause className="h-4 w-4" />
              Pausar
            </Button>
            <Button 
              onClick={() => onStatusChange(task.id, "completed")}
              className="gap-2 bg-success hover:bg-success/90"
            >
              <CheckCircle className="h-4 w-4" />
              Concluir
            </Button>
          </div>
        );
      case "completed":
        return (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              Concluída às {getCompletedTime()}
            </span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onStatusChange(task.id, "not_started")}
              className="gap-2"
            >
              <RotateCcw className="h-3 w-3" />
              Reabrir
            </Button>
          </div>
        );
    }
  };

  return (
    <Card className={cn(
      "border-l-4 transition-all duration-300 hover:shadow-md",
      getPriorityColor(),
      task.status === "completed" && "opacity-75"
    )}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          {/* Status Icon */}
          <div className="mt-1">
            {getStatusIcon()}
          </div>

          {/* Task Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h4 className="font-semibold text-foreground mb-1">{task.title}</h4>
                <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
                
                <div className="flex items-center gap-3 mb-3">
                  <Badge className={cn(task.marketplaceColor, "text-white")}>
                    {task.marketplace}
                  </Badge>
                  
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {task.status === "in_progress" ? (
                      <span>{getElapsedTime()}/{task.estimatedTime}min</span>
                    ) : (
                      <span>{task.estimatedTime}min</span>
                    )}
                  </div>

                  {task.urls && task.urls.length > 0 && (
                    <Dialog open={showUrls} onOpenChange={setShowUrls}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-2">
                          <ExternalLink className="h-3 w-3" />
                          Links ({task.urls.length})
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Links de Referência</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-2">
                          {task.urls.map((url, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <ExternalLink className="h-4 w-4 text-muted-foreground" />
                              <a 
                                href={url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-primary hover:underline flex-1 truncate"
                              >
                                {url}
                              </a>
                            </div>
                          ))}
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex-shrink-0">
                {renderActionButtons()}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};