import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Calendar, ChevronDown, ChevronRight, Clock, AlertTriangle } from "lucide-react";
import { DailyTaskCard } from "./DailyTaskCard";
import { Task } from "@/pages/DailyTasks";
import { cn } from "@/lib/utils";

const mockMonthlyTasks: Task[] = [
  {
    id: "m1",
    title: "Relatório de vendas do mês",
    description: "Compilar dados completos do período e análise comparativa",
    marketplace: "Shopee Filial",
    marketplaceColor: "bg-shopee",
    estimatedTime: 45,
    status: "not_started",
    priority: "high"
  },
  {
    id: "m2",
    title: "Análise de retornos e cancelamentos",
    description: "Identificar padrões e oportunidades de melhoria",
    marketplace: "Mercado Livre Matriz",
    marketplaceColor: "bg-mercadolivre",
    estimatedTime: 30,
    status: "not_started",
    priority: "medium"
  },
  {
    id: "m3",
    title: "Revisão de métricas de marketing",
    description: "ROI de campanhas e planejamento para próximo mês",
    marketplace: "Geral",
    marketplaceColor: "bg-muted",
    estimatedTime: 40,
    status: "not_started",
    priority: "medium"
  }
];

export const MonthlySection = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const getPendingTasks = () => {
    return mockMonthlyTasks.filter(task => task.status !== "completed").length;
  };

  const getDaysUntilMonthEnd = () => {
    const now = new Date();
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const daysUntilEnd = Math.ceil((nextMonth.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilEnd;
  };

  const getUrgentTasks = () => {
    const daysLeft = getDaysUntilMonthEnd();
    return daysLeft <= 5 ? mockMonthlyTasks.filter(task => task.status !== "completed") : [];
  };

  const updateTaskStatus = (taskId: string, status: any) => {
    // In a real app, this would update the task status
    console.log("Update monthly task", taskId, "to", status);
  };

  const urgentTasks = getUrgentTasks();
  const daysLeft = getDaysUntilMonthEnd();

  return (
    <div className="space-y-4">
      {urgentTasks.length > 0 && (
        <Card className="border-warning bg-warning/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <AlertTriangle className="h-5 w-5 text-warning" />
              <h3 className="font-semibold text-foreground">Urgente - Fechamento Mensal</h3>
              <Badge variant="secondary" className="bg-warning/20 text-warning">
                {daysLeft} dias restantes
              </Badge>
            </div>
            <div className="space-y-3">
              {urgentTasks.map(task => (
                <DailyTaskCard 
                  key={task.id}
                  task={task}
                  onStatusChange={updateTaskStatus}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CollapsibleTrigger asChild>
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Calendar className="h-6 w-6 text-muted-foreground" />
                  <div>
                    <h2 className="text-xl font-bold text-foreground">Rotinas Mensais</h2>
                    <p className="text-sm text-muted-foreground">
                      {getPendingTasks()} pendentes - próxima em {daysLeft} dias
                    </p>
                  </div>
                  <Badge variant="outline">{mockMonthlyTasks.length} total</Badge>
                </div>
                
                <div className="flex items-center gap-4">
                  {!isExpanded && (
                    <div className="text-right">
                      <p className="text-sm font-medium text-foreground">
                        {getPendingTasks()} tarefas mensais
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {mockMonthlyTasks.reduce((sum, task) => sum + task.estimatedTime, 0)}min total
                      </p>
                    </div>
                  )}
                  {isExpanded ? (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </CollapsibleTrigger>

        <CollapsibleContent className="space-y-4">
          <div className="grid gap-3">
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-foreground mb-2">
                Tarefas do Mês - {new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-muted-foreground">Tempo Total</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">
                      {mockMonthlyTasks.reduce((sum, task) => sum + task.estimatedTime, 0)}min
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-warning" />
                      <span className="text-sm font-medium text-muted-foreground">Alta Prioridade</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">
                      {mockMonthlyTasks.filter(t => t.priority === "high").length}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-muted-foreground">Dias Restantes</span>
                    </div>
                    <p className="text-2xl font-bold text-foreground">{daysLeft}</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {mockMonthlyTasks.map(task => (
              <DailyTaskCard 
                key={task.id}
                task={task}
                onStatusChange={updateTaskStatus}
              />
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};