import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { CalendarDays, ChevronDown, ChevronRight, Clock } from "lucide-react";
import { DailyTaskCard } from "./DailyTaskCard";
import { Task } from "@/pages/DailyTasks";
import { cn } from "@/lib/utils";

const mockWeeklyTasks: Task[] = [
  {
    id: "w1",
    title: "Análise de métricas 1D, 7D, 30D",
    description: "Comparação detalhada de performance entre períodos",
    marketplace: "Shopee Filial",
    marketplaceColor: "bg-shopee",
    estimatedTime: 30,
    urls: ["https://seller.shopee.com.br/datacenter/overview"],
    status: "not_started",
    priority: "high"
  },
  {
    id: "w2",
    title: "Verificação de promoções ativas",
    description: "Revisar campanhas e ajustar conforme necessário",
    marketplace: "Shopee Filial",
    marketplaceColor: "bg-shopee",
    estimatedTime: 15,
    status: "not_started",
    priority: "medium"
  },
  {
    id: "w3",
    title: "Planejamento da semana",
    description: "Definir metas e prioridades para os próximos dias",
    marketplace: "Geral",
    marketplaceColor: "bg-muted",
    estimatedTime: 45,
    status: "not_started",
    priority: "low"
  }
];

const weekDays = [
  { key: "monday", label: "Segunda-feira", tasks: mockWeeklyTasks },
  { key: "tuesday", label: "Terça-feira", tasks: [] },
  { key: "wednesday", label: "Quarta-feira", tasks: [] },
  { key: "thursday", label: "Quinta-feira", tasks: [] },
  { key: "friday", label: "Sexta-feira", tasks: [] },
  { key: "saturday", label: "Sábado", tasks: [] },
  { key: "sunday", label: "Domingo", tasks: [] }
];

export const WeeklySection = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [expandedDay, setExpandedDay] = useState<string>("monday"); // Current day auto-expanded
  
  const getTotalWeeklyTasks = () => {
    return weekDays.reduce((total, day) => total + day.tasks.length, 0);
  };

  const getPendingTasks = () => {
    return weekDays.reduce((total, day) => {
      return total + day.tasks.filter(task => task.status !== "completed").length;
    }, 0);
  };

  const updateTaskStatus = (taskId: string, status: any) => {
    // In a real app, this would update the task status
    console.log("Update task", taskId, "to", status);
  };

  const getCurrentDay = () => {
    const days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    return days[new Date().getDay()];
  };

  return (
    <div className="space-y-4">
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CollapsibleTrigger asChild>
          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CalendarDays className="h-6 w-6 text-primary" />
                  <div>
                    <h2 className="text-xl font-bold text-foreground">Rotinas Semanais</h2>
                    <p className="text-sm text-muted-foreground">
                      {getPendingTasks()} tarefas pendentes esta semana
                    </p>
                  </div>
                  <Badge variant="secondary">{getTotalWeeklyTasks()} total</Badge>
                </div>
                
                <div className="flex items-center gap-4">
                  {!isExpanded && (
                    <div className="text-right">
                      <p className="text-sm font-medium text-foreground">Segunda-feira</p>
                      <p className="text-xs text-muted-foreground">3 tarefas semanais</p>
                    </div>
                  )}
                  {isExpanded ? (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </CollapsibleTrigger>

        <CollapsibleContent className="space-y-4">
          <div className="grid gap-4">
            {weekDays.map((day) => (
              <Collapsible 
                key={day.key}
                open={expandedDay === day.key}
                onOpenChange={(open) => setExpandedDay(open ? day.key : "")}
              >
                <CollapsibleTrigger asChild>
                  <Card className={cn(
                    "cursor-pointer hover:shadow-sm transition-shadow",
                    day.key === getCurrentDay() && "ring-2 ring-primary/20 bg-primary/5"
                  )}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-3 h-3 rounded-full",
                            day.key === getCurrentDay() ? "bg-primary" : "bg-muted"
                          )} />
                          <h3 className="font-semibold text-foreground">{day.label}</h3>
                          {day.key === getCurrentDay() && (
                            <Badge variant="default">Hoje</Badge>
                          )}
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <p className="text-sm font-medium text-foreground">
                              {day.tasks.length} tarefas
                            </p>
                            {day.tasks.length > 0 && (
                              <p className="text-xs text-muted-foreground">
                                {day.tasks.reduce((sum, task) => sum + task.estimatedTime, 0)}min estimados
                              </p>
                            )}
                          </div>
                          {expandedDay === day.key ? (
                            <ChevronDown className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-muted-foreground" />
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </CollapsibleTrigger>

                <CollapsibleContent className="space-y-3 ml-4">
                  {day.tasks.length > 0 ? (
                    day.tasks.map(task => (
                      <DailyTaskCard 
                        key={task.id}
                        task={task}
                        onStatusChange={updateTaskStatus}
                      />
                    ))
                  ) : (
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-muted-foreground">Nenhuma tarefa semanal configurada para este dia</p>
                      </CardContent>
                    </Card>
                  )}
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};