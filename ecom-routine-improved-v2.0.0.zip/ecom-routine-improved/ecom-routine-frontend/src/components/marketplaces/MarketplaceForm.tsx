import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, X, Palette, Save, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

interface MarketplaceFormProps {
  open: boolean;
  onClose: () => void;
  marketplace?: any;
  onSave: (marketplace: any) => void;
}

const predefinedColors = [
  "#3B82F6", // Blue
  "#EF4444", // Red
  "#10B981", // Green
  "#F59E0B", // Yellow
  "#8B5CF6", // Purple
  "#F97316", // Orange
  "#EC4899", // Pink
  "#06B6D4", // Cyan
  "#84CC16", // Lime
  "#6366F1", // Indigo
];

const marketplaceTypes = [
  { value: "ecommerce", label: "E-commerce" },
  { value: "physical", label: "Loja Física" },
  { value: "hybrid", label: "Híbrido" },
  { value: "b2b", label: "B2B" },
  { value: "international", label: "Internacional" },
  { value: "testing", label: "Teste/Desenvolvimento" },
];

const priorityLevels = [
  { value: "high", label: "Alta", color: "text-red-600" },
  { value: "medium", label: "Média", color: "text-yellow-600" },
  { value: "low", label: "Baixa", color: "text-green-600" },
];

export const MarketplaceForm = ({ open, onClose, marketplace, onSave }: MarketplaceFormProps) => {
  const [formData, setFormData] = useState({
    name: marketplace?.name || "",
    description: marketplace?.description || "",
    color: marketplace?.color || predefinedColors[0],
    logoUrl: marketplace?.logoUrl || "",
    type: marketplace?.type || "",
    priority: marketplace?.priority || "medium",
    tags: marketplace?.tags || [],
    responsible: marketplace?.responsible || "",
    urls: marketplace?.urls || { admin: "", reports: "", other: "" },
    schedule: marketplace?.schedule || { start: "09:00", end: "18:00" },
    timezone: marketplace?.timezone || "America/Sao_Paulo",
    customFields: marketplace?.customFields || [],
  });

  const [newTag, setNewTag] = useState("");
  const [newCustomField, setNewCustomField] = useState({ name: "", type: "text", value: "" });
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = () => {
    const marketplaceData = {
      ...marketplace,
      ...formData,
      id: marketplace?.id || `marketplace-${Date.now()}`,
      createdAt: marketplace?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    onSave(marketplaceData);
    onClose();
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, newTag.trim()]
      });
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(tag => tag !== tagToRemove)
    });
  };

  const addCustomField = () => {
    if (newCustomField.name.trim()) {
      setFormData({
        ...formData,
        customFields: [...formData.customFields, { ...newCustomField, id: Date.now() }]
      });
      setNewCustomField({ name: "", type: "text", value: "" });
    }
  };

  const removeCustomField = (fieldId: number) => {
    setFormData({
      ...formData,
      customFields: formData.customFields.filter(field => field.id !== fieldId)
    });
  };

  const handleFileUpload = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData({ ...formData, logoUrl: e.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {marketplace ? "Editar Marketplace" : "Novo Marketplace"}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basic">📋 Básico</TabsTrigger>
            <TabsTrigger value="categories">🏷️ Categorias</TabsTrigger>
            <TabsTrigger value="settings">⚙️ Configurações</TabsTrigger>
            <TabsTrigger value="custom">🔧 Personalizado</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome do Marketplace *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Mercado Livre Matriz"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descreva o marketplace e sua função..."
                    className="mt-1 min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Cor de Identificação</Label>
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-8 h-8 rounded border-2 border-white shadow-sm"
                          style={{ backgroundColor: formData.color }}
                        />
                        <Input
                          type="color"
                          value={formData.color}
                          onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                          className="w-16 h-8 p-1 cursor-pointer"
                        />
                      </div>
                      <div className="grid grid-cols-5 gap-1">
                        {predefinedColors.map((color) => (
                          <button
                            key={color}
                            className="w-6 h-6 rounded border-2 border-white shadow-sm hover:scale-110 transition-transform"
                            style={{ backgroundColor: color }}
                            onClick={() => setFormData({ ...formData, color })}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label>Logo/Ícone</Label>
                    <div
                      className={cn(
                        "mt-2 border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors",
                        dragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25"
                      )}
                      onDragEnter={handleDrag}
                      onDragLeave={handleDrag}
                      onDragOver={handleDrag}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                    >
                      {formData.logoUrl ? (
                        <div className="space-y-2">
                          <img 
                            src={formData.logoUrl} 
                            alt="Logo" 
                            className="w-12 h-12 object-cover rounded mx-auto"
                          />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              setFormData({ ...formData, logoUrl: "" });
                            }}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">
                            Clique ou arraste uma imagem
                          </p>
                        </div>
                      )}
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files?.[0]) {
                            handleFileUpload(e.target.files[0]);
                          }
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Card className="p-4">
                  <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    Preview
                  </h3>
                  <div className="border rounded-lg p-3">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-lg"
                        style={{ backgroundColor: formData.color }}
                      >
                        {formData.logoUrl ? (
                          <img src={formData.logoUrl} alt="Logo" className="w-10 h-10 object-cover rounded" />
                        ) : (
                          formData.name.slice(0, 2).toUpperCase()
                        )}
                      </div>
                      <div>
                        <h4 className="font-semibold">{formData.name || "Nome do Marketplace"}</h4>
                        <p className="text-sm text-muted-foreground">
                          {formData.description || "Descrição do marketplace"}
                        </p>
                        <div className="flex gap-1 mt-1">
                          {formData.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="categories" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label>Tipo de Marketplace</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {marketplaceTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Prioridade</Label>
                  <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Selecione a prioridade" />
                    </SelectTrigger>
                    <SelectContent>
                      {priorityLevels.map((priority) => (
                        <SelectItem key={priority.value} value={priority.value}>
                          <span className={priority.color}>{priority.label}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="responsible">Responsável</Label>
                  <Input
                    id="responsible"
                    value={formData.responsible}
                    onChange={(e) => setFormData({ ...formData, responsible: e.target.value })}
                    placeholder="Nome do responsável ou equipe"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>Tags</Label>
                  <div className="mt-1 space-y-2">
                    <div className="flex gap-2">
                      <Input
                        value={newTag}
                        onChange={(e) => setNewTag(e.target.value)}
                        placeholder="Adicionar tag..."
                        onKeyPress={(e) => e.key === 'Enter' && addTag()}
                      />
                      <Button onClick={addTag} size="sm">Adicionar</Button>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {formData.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="gap-1">
                          {tag}
                          <X 
                            className="w-3 h-3 cursor-pointer hover:text-destructive" 
                            onClick={() => removeTag(tag)}
                          />
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Horário de Funcionamento</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="start-time">Início</Label>
                    <Input
                      id="start-time"
                      type="time"
                      value={formData.schedule.start}
                      onChange={(e) => setFormData({
                        ...formData,
                        schedule: { ...formData.schedule, start: e.target.value }
                      })}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="end-time">Fim</Label>
                    <Input
                      id="end-time"
                      type="time"
                      value={formData.schedule.end}
                      onChange={(e) => setFormData({
                        ...formData,
                        schedule: { ...formData.schedule, end: e.target.value }
                      })}
                      className="mt-1"
                    />
                  </div>
                </div>

                <div>
                  <Label>Fuso Horário</Label>
                  <Select 
                    value={formData.timezone} 
                    onValueChange={(value) => setFormData({ ...formData, timezone: value })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/Sao_Paulo">São Paulo (GMT-3)</SelectItem>
                      <SelectItem value="America/New_York">Nova York (GMT-5)</SelectItem>
                      <SelectItem value="Europe/London">Londres (GMT+0)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-semibold">URLs Importantes</h3>
                <div>
                  <Label htmlFor="admin-url">Painel Administrativo</Label>
                  <Input
                    id="admin-url"
                    type="url"
                    value={formData.urls.admin}
                    onChange={(e) => setFormData({
                      ...formData,
                      urls: { ...formData.urls, admin: e.target.value }
                    })}
                    placeholder="https://admin.marketplace.com"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="reports-url">Relatórios</Label>
                  <Input
                    id="reports-url"
                    type="url"
                    value={formData.urls.reports}
                    onChange={(e) => setFormData({
                      ...formData,
                      urls: { ...formData.urls, reports: e.target.value }
                    })}
                    placeholder="https://reports.marketplace.com"
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="other-url">Outros Links</Label>
                  <Input
                    id="other-url"
                    type="url"
                    value={formData.urls.other}
                    onChange={(e) => setFormData({
                      ...formData,
                      urls: { ...formData.urls, other: e.target.value }
                    })}
                    placeholder="https://other.marketplace.com"
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Campos Personalizados</h3>
              
              <div className="space-y-4">
                <Card className="p-4">
                  <h4 className="font-medium mb-3">Adicionar Novo Campo</h4>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <Input
                      placeholder="Nome do campo"
                      value={newCustomField.name}
                      onChange={(e) => setNewCustomField({ ...newCustomField, name: e.target.value })}
                    />
                    <Select 
                      value={newCustomField.type} 
                      onValueChange={(value) => setNewCustomField({ ...newCustomField, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="text">Texto</SelectItem>
                        <SelectItem value="number">Número</SelectItem>
                        <SelectItem value="url">URL</SelectItem>
                        <SelectItem value="date">Data</SelectItem>
                        <SelectItem value="select">Lista de Opções</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="Valor"
                      value={newCustomField.value}
                      onChange={(e) => setNewCustomField({ ...newCustomField, value: e.target.value })}
                    />
                    <Button onClick={addCustomField}>Adicionar</Button>
                  </div>
                </Card>

                <div className="space-y-3">
                  {formData.customFields.map((field) => (
                    <Card key={field.id} className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 grid grid-cols-3 gap-3">
                          <div>
                            <span className="text-sm font-medium">{field.name}</span>
                            <p className="text-xs text-muted-foreground">{field.type}</p>
                          </div>
                          <div className="col-span-2">
                            <span className="text-sm">{field.value}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeCustomField(field.id)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-3 pt-6 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} className="gap-2">
            <Save className="w-4 h-4" />
            {marketplace ? "Salvar Alterações" : "Criar Marketplace"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};