import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  MoreHorizontal, 
  Edit2, 
  Copy, 
  Trash2, 
  ExternalLink,
  Calendar,
  Settings,
  Star,
  StarOff,
  CheckCircle,
  Clock
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

interface Marketplace {
  id: string;
  name: string;
  description: string;
  color: string;
  logoUrl?: string;
  type: string;
  priority: string;
  tags: string[];
  responsible: string;
  active: boolean;
  favorite?: boolean;
  createdAt: string;
  updatedAt: string;
  weeklyTasks: {
    total: number;
    completed: number;
    pending: number;
  };
}

interface MarketplaceGridProps {
  marketplaces: Marketplace[];
  onEdit: (marketplace: Marketplace) => void;
  onDuplicate: (marketplace: Marketplace) => void;
  onDelete: (marketplace: Marketplace) => void;
  onToggleFavorite: (marketplace: Marketplace) => void;
  onToggleActive: (marketplace: Marketplace) => void;
  onViewRoutines: (marketplace: Marketplace) => void;
}

export const MarketplaceGrid = ({ 
  marketplaces, 
  onEdit, 
  onDuplicate, 
  onDelete,
  onToggleFavorite,
  onToggleActive,
  onViewRoutines
}: MarketplaceGridProps) => {
  const [viewMode, setViewMode] = useState<'cards' | 'list'>('cards');

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return 'Alta';
      case 'medium': return 'Média';
      case 'low': return 'Baixa';
      default: return priority;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'ecommerce': return 'E-commerce';
      case 'physical': return 'Loja Física';
      case 'hybrid': return 'Híbrido';
      case 'b2b': return 'B2B';
      case 'international': return 'Internacional';
      case 'testing': return 'Teste';
      default: return type;
    }
  };

  if (viewMode === 'list') {
    return (
      <div className="space-y-2">
        <div className="grid grid-cols-12 gap-4 px-4 py-2 text-sm font-medium text-muted-foreground border-b">
          <div className="col-span-1"></div>
          <div className="col-span-3">Nome</div>
          <div className="col-span-2">Tipo</div>
          <div className="col-span-2">Prioridade</div>
          <div className="col-span-2">Responsável</div>
          <div className="col-span-1">Status</div>
          <div className="col-span-1">Ações</div>
        </div>
        
        {marketplaces.map((marketplace) => (
          <Card key={marketplace.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="grid grid-cols-12 gap-4 items-center">
                <div className="col-span-1">
                  <div 
                    className="w-8 h-8 rounded flex items-center justify-center text-white text-sm font-bold"
                    style={{ backgroundColor: marketplace.color }}
                  >
                    {marketplace.logoUrl ? (
                      <img src={marketplace.logoUrl} alt="" className="w-6 h-6 object-cover rounded" />
                    ) : (
                      marketplace.name.slice(0, 2).toUpperCase()
                    )}
                  </div>
                </div>
                
                <div className="col-span-3">
                  <div className="flex items-center gap-2">
                    {marketplace.favorite && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                    <div>
                      <h3 className="font-medium">{marketplace.name}</h3>
                      <p className="text-sm text-muted-foreground truncate">
                        {marketplace.description}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="col-span-2">
                  <Badge variant="outline">{getTypeLabel(marketplace.type)}</Badge>
                </div>
                
                <div className="col-span-2">
                  <Badge 
                    variant="outline" 
                    className={getPriorityColor(marketplace.priority)}
                  >
                    {getPriorityLabel(marketplace.priority)}
                  </Badge>
                </div>
                
                <div className="col-span-2">
                  <span className="text-sm">{marketplace.responsible || "Não definido"}</span>
                </div>
                
                <div className="col-span-1">
                  <Badge variant={marketplace.active ? "default" : "secondary"}>
                    {marketplace.active ? "Ativo" : "Inativo"}
                  </Badge>
                </div>
                
                <div className="col-span-1">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onEdit(marketplace)}>
                        <Edit2 className="w-4 h-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onDuplicate(marketplace)}>
                        <Copy className="w-4 h-4 mr-2" />
                        Duplicar
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onToggleFavorite(marketplace)}>
                        {marketplace.favorite ? (
                          <><StarOff className="w-4 h-4 mr-2" />Remover dos Favoritos</>
                        ) : (
                          <><Star className="w-4 h-4 mr-2" />Adicionar aos Favoritos</>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={() => onDelete(marketplace)}
                        className="text-destructive"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Excluir
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {marketplaces.map((marketplace) => (
        <Card 
          key={marketplace.id} 
          className={cn(
            "group hover:shadow-lg transition-all duration-200 cursor-pointer relative",
            !marketplace.active && "opacity-75"
          )}
        >
          <CardContent className="p-6">
            {/* Header with logo and actions */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-lg shadow-sm"
                  style={{ backgroundColor: marketplace.color }}
                >
                  {marketplace.logoUrl ? (
                    <img 
                      src={marketplace.logoUrl} 
                      alt={marketplace.name} 
                      className="w-10 h-10 object-cover rounded-md"
                    />
                  ) : (
                    marketplace.name.slice(0, 2).toUpperCase()
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    {marketplace.favorite && (
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    )}
                    <h3 className="font-semibold text-lg truncate">
                      {marketplace.name}
                    </h3>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={cn("text-xs", getPriorityColor(marketplace.priority))}
                  >
                    {getPriorityLabel(marketplace.priority)}
                  </Badge>
                </div>
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit(marketplace)}>
                    <Edit2 className="w-4 h-4 mr-2" />
                    Editar
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDuplicate(marketplace)}>
                    <Copy className="w-4 h-4 mr-2" />
                    Duplicar
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onToggleFavorite(marketplace)}>
                    {marketplace.favorite ? (
                      <><StarOff className="w-4 h-4 mr-2" />Desfavoritar</>
                    ) : (
                      <><Star className="w-4 h-4 mr-2" />Favoritar</>
                    )}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => onToggleActive(marketplace)}>
                    <Settings className="w-4 h-4 mr-2" />
                    {marketplace.active ? "Desativar" : "Ativar"}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => onDelete(marketplace)}
                    className="text-destructive"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Excluir
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Description */}
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {marketplace.description || "Sem descrição"}
            </p>

            {/* Type and Status */}
            <div className="flex items-center justify-between mb-4">
              <Badge variant="outline">
                {getTypeLabel(marketplace.type)}
              </Badge>
              <Badge variant={marketplace.active ? "default" : "secondary"}>
                {marketplace.active ? "Ativo" : "Inativo"}
              </Badge>
            </div>

            {/* Weekly Tasks Progress */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Tarefas da Semana</span>
                <span className="text-sm font-medium">
                  {marketplace.weeklyTasks.completed}/{marketplace.weeklyTasks.total}
                </span>
              </div>
              <Progress 
                value={(marketplace.weeklyTasks.completed / marketplace.weeklyTasks.total) * 100} 
                className="h-2"
              />
              
              <div className="grid grid-cols-2 gap-3">
                <div className="text-center p-3 rounded-lg bg-success/10 border border-success/20">
                  <CheckCircle className="h-4 w-4 mx-auto mb-1 text-success" />
                  <div className="font-bold text-success">{marketplace.weeklyTasks.completed}</div>
                  <div className="text-xs text-success">Concluídas</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-warning/10 border border-warning/20">
                  <Clock className="h-4 w-4 mx-auto mb-1 text-warning" />
                  <div className="font-bold text-warning">{marketplace.weeklyTasks.pending}</div>
                  <div className="text-xs text-warning">Pendentes</div>
                </div>
              </div>
            </div>

            {/* Tags */}
            {marketplace.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mb-4">
                {marketplace.tags.slice(0, 2).map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
                {marketplace.tags.length > 2 && (
                  <Badge variant="secondary" className="text-xs">
                    +{marketplace.tags.length - 2}
                  </Badge>
                )}
              </div>
            )}

            {/* Responsible */}
            {marketplace.responsible && (
              <div className="text-sm text-muted-foreground mb-2">
                <strong>Responsável:</strong> {marketplace.responsible}
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1"
                onClick={() => onEdit(marketplace)}
              >
                <Edit2 className="w-3 h-3 mr-1" />
                Editar
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => onViewRoutines(marketplace)}
              >
                <Calendar className="w-3 h-3 mr-1" />
                Rotinas
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};