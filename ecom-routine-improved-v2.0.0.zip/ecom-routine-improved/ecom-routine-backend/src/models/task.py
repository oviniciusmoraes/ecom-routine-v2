from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Task(db.Model):
    __tablename__ = 'tasks'
    
    id = db.Column(db.String(100), primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    status = db.Column(db.String(20), default='todo')  # todo, in-progress, completed, overdue
    priority = db.Column(db.String(20), default='medium')  # critical, high, medium, low
    category = db.Column(db.String(100))
    
    # Relationships
    marketplace_id = db.Column(db.String(100), db.ForeignKey('marketplaces.id'), nullable=False)
    routine_id = db.Column(db.Integer, db.ForeignKey('routines.id'), nullable=True)
    assignee_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    # Timing
    due_date = db.Column(db.DateTime)
    estimated_time = db.Column(db.Integer)  # in minutes
    actual_time = db.Column(db.Integer)     # in minutes
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    # Task details
    links = db.Column(db.Text)  # JSON string of related links
    notes = db.Column(db.Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, **kwargs):
        super(Task, self).__init__(**kwargs)
        if self.links and isinstance(self.links, list):
            self.links = json.dumps(self.links)
    
    def to_dict(self):
        assignee_info = None
        if self.assignee_id:
            from src.models.user import User
            assignee = User.query.get(self.assignee_id)
            if assignee:
                assignee_info = {
                    'name': assignee.name,
                    'initials': assignee.get_initials(),
                    'avatar': assignee.avatar_url
                }
        
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'category': self.category,
            'marketplace': self.marketplace_id,
            'routineId': self.routine_id,
            'assignee': assignee_info,
            'dueDate': self.format_due_date(),
            'estimatedTime': self.estimated_time,
            'actualTime': self.actual_time,
            'startedAt': self.started_at.isoformat() if self.started_at else None,
            'completedAt': self.completed_at.isoformat() if self.completed_at else None,
            'links': json.loads(self.links) if self.links else [],
            'notes': self.notes,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def format_due_date(self):
        if not self.due_date:
            return None
        
        now = datetime.utcnow()
        diff = self.due_date - now
        
        if diff.days == 0:
            if diff.seconds > 0:
                return f"Hoje, {self.due_date.strftime('%H:%M')}"
            else:
                return "Hoje (atrasado)"
        elif diff.days == 1:
            return f"Amanhã, {self.due_date.strftime('%H:%M')}"
        elif diff.days == -1:
            return f"Ontem, {self.due_date.strftime('%H:%M')}"
        elif diff.days > 1:
            return f"Em {diff.days} dias, {self.due_date.strftime('%H:%M')}"
        else:
            return f"Há {abs(diff.days)} dias, {self.due_date.strftime('%H:%M')}"
    
    def start_task(self):
        """Mark task as started"""
        self.status = 'in-progress'
        self.started_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    def complete_task(self):
        """Mark task as completed"""
        self.status = 'completed'
        self.completed_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        if self.started_at:
            time_diff = self.completed_at - self.started_at
            self.actual_time = int(time_diff.total_seconds() / 60)  # Convert to minutes
    
    def pause_task(self):
        """Pause task (back to todo)"""
        self.status = 'todo'
        self.updated_at = datetime.utcnow()
    
    @classmethod
    def create_from_dict(cls, data):
        task = cls(
            id=data.get('id'),
            title=data.get('title'),
            description=data.get('description'),
            status=data.get('status', 'todo'),
            priority=data.get('priority', 'medium'),
            category=data.get('category'),
            marketplace_id=data.get('marketplace'),
            routine_id=data.get('routineId'),
            assignee_id=data.get('assigneeId'),
            due_date=datetime.fromisoformat(data['dueDate']) if data.get('dueDate') else None,
            estimated_time=data.get('estimatedTime'),
            links=json.dumps(data.get('links', [])),
            notes=data.get('notes')
        )
        return task


class DailyTaskSummary(db.Model):
    __tablename__ = 'daily_task_summaries'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, unique=True)
    total_tasks = db.Column(db.Integer, default=0)
    completed_tasks = db.Column(db.Integer, default=0)
    pending_tasks = db.Column(db.Integer, default=0)
    overdue_tasks = db.Column(db.Integer, default=0)
    total_time_estimated = db.Column(db.Integer, default=0)  # in minutes
    total_time_actual = db.Column(db.Integer, default=0)     # in minutes
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat(),
            'totalTasks': self.total_tasks,
            'completedTasks': self.completed_tasks,
            'pendingTasks': self.pending_tasks,
            'overdueTasks': self.overdue_tasks,
            'totalTimeEstimated': self.total_time_estimated,
            'totalTimeActual': self.total_time_actual,
            'completionRate': round((self.completed_tasks / self.total_tasks * 100) if self.total_tasks > 0 else 0, 1),
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None
        }

