from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import jwt
import os

# This will be set by main.py
db = None

def init_db(database):
    global db
    db = database

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    
    # Profile information
    name = db.Column(db.String(200))
    avatar_url = db.Column(db.String(500))
    role = db.Column(db.String(50), default='user')  # admin, manager, user
    active = db.Column(db.Boolean, default=True)
    
    # Preferences
    timezone = db.Column(db.String(50), default='America/Sao_Paulo')
    notifications_enabled = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships (commented to avoid circular imports)
    # assigned_tasks = db.relationship('Task', backref='assignee', lazy=True)

    def __repr__(self):
        return f'<User {self.username}>'
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if provided password matches hash"""
        return check_password_hash(self.password_hash, password)
    
    def get_initials(self):
        """Get user initials from name or username"""
        if self.name:
            parts = self.name.split()
            if len(parts) >= 2:
                return f"{parts[0][0]}{parts[1][0]}".upper()
            else:
                return parts[0][:2].upper()
        else:
            return self.username[:2].upper()
    
    def generate_token(self):
        """Generate JWT token for authentication"""
        payload = {
            'user_id': self.id,
            'username': self.username,
            'exp': datetime.utcnow().timestamp() + 86400  # 24 hours
        }
        return jwt.encode(payload, os.environ.get('SECRET_KEY', 'default-secret'), algorithm='HS256')
    
    @staticmethod
    def verify_token(token):
        """Verify JWT token and return user"""
        try:
            payload = jwt.decode(token, os.environ.get('SECRET_KEY', 'default-secret'), algorithms=['HS256'])
            user = User.query.get(payload['user_id'])
            return user
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def update_last_login(self):
        """Update last login timestamp"""
        self.last_login = datetime.utcnow()
        db.session.commit()

    def to_dict(self, include_sensitive=False):
        data = {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'name': self.name,
            'avatarUrl': self.avatar_url,
            'role': self.role,
            'active': self.active,
            'timezone': self.timezone,
            'notificationsEnabled': self.notifications_enabled,
            'initials': self.get_initials(),
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None,
            'lastLogin': self.last_login.isoformat() if self.last_login else None
        }
        
        if include_sensitive:
            data['passwordHash'] = self.password_hash
        
        return data
    
    @classmethod
    def create_from_dict(cls, data):
        user = cls(
            username=data.get('username'),
            email=data.get('email'),
            name=data.get('name'),
            avatar_url=data.get('avatarUrl'),
            role=data.get('role', 'user'),
            active=data.get('active', True),
            timezone=data.get('timezone', 'America/Sao_Paulo'),
            notifications_enabled=data.get('notificationsEnabled', True)
        )
        
        if data.get('password'):
            user.set_password(data['password'])
        
        return user

