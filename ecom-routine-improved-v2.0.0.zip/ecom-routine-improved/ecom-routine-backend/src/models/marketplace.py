from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Marketplace(db.Model):
    __tablename__ = 'marketplaces'
    
    id = db.Column(db.String(100), primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    color = db.Column(db.String(7), default='#3B82F6')  # Hex color
    logo_url = db.Column(db.String(500))
    type = db.Column(db.String(50), nullable=False)  # ecommerce, physical, hybrid, etc.
    priority = db.Column(db.String(20), default='medium')  # high, medium, low
    tags = db.Column(db.Text)  # JSON string of tags
    responsible = db.Column(db.String(200))
    active = db.Column(db.Boolean, default=True)
    favorite = db.Column(db.Boolean, default=False)
    
    # URLs
    admin_url = db.Column(db.String(500))
    reports_url = db.Column(db.String(500))
    other_url = db.Column(db.String(500))
    
    # Schedule
    schedule_start = db.Column(db.String(5))  # HH:MM format
    schedule_end = db.Column(db.String(5))    # HH:MM format
    timezone = db.Column(db.String(50), default='America/Sao_Paulo')
    
    # Custom fields
    custom_fields = db.Column(db.Text)  # JSON string
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships (commented to avoid circular imports)
    # routines = db.relationship('Routine', backref='marketplace_ref', lazy=True, cascade='all, delete-orphan')
    # tasks = db.relationship('Task', backref='marketplace_ref', lazy=True, cascade='all, delete-orphan')
    
    def __init__(self, **kwargs):
        super(Marketplace, self).__init__(**kwargs)
        if self.tags and isinstance(self.tags, list):
            self.tags = json.dumps(self.tags)
        if self.custom_fields and isinstance(self.custom_fields, list):
            self.custom_fields = json.dumps(self.custom_fields)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'color': self.color,
            'logoUrl': self.logo_url,
            'type': self.type,
            'priority': self.priority,
            'tags': json.loads(self.tags) if self.tags else [],
            'responsible': self.responsible,
            'active': self.active,
            'favorite': self.favorite,
            'urls': {
                'admin': self.admin_url,
                'reports': self.reports_url,
                'other': self.other_url
            },
            'schedule': {
                'start': self.schedule_start,
                'end': self.schedule_end
            },
            'timezone': self.timezone,
            'customFields': json.loads(self.custom_fields) if self.custom_fields else [],
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None,
            'weeklyTasks': self.get_weekly_tasks_stats()
        }
    
    def get_weekly_tasks_stats(self):
        from src.models.task import Task
        from datetime import datetime, timedelta
        
        # Get tasks from the last 7 days
        week_ago = datetime.utcnow() - timedelta(days=7)
        tasks = Task.query.filter(
            Task.marketplace_id == self.id,
            Task.created_at >= week_ago
        ).all()
        
        total = len(tasks)
        completed = len([t for t in tasks if t.status == 'completed'])
        pending = total - completed
        
        return {
            'total': total,
            'completed': completed,
            'pending': pending
        }
    
    @classmethod
    def create_from_dict(cls, data):
        marketplace = cls(
            id=data.get('id'),
            name=data.get('name'),
            description=data.get('description'),
            color=data.get('color', '#3B82F6'),
            logo_url=data.get('logoUrl'),
            type=data.get('type'),
            priority=data.get('priority', 'medium'),
            tags=json.dumps(data.get('tags', [])),
            responsible=data.get('responsible'),
            active=data.get('active', True),
            favorite=data.get('favorite', False),
            admin_url=data.get('urls', {}).get('admin'),
            reports_url=data.get('urls', {}).get('reports'),
            other_url=data.get('urls', {}).get('other'),
            schedule_start=data.get('schedule', {}).get('start'),
            schedule_end=data.get('schedule', {}).get('end'),
            timezone=data.get('timezone', 'America/Sao_Paulo'),
            custom_fields=json.dumps(data.get('customFields', []))
        )
        return marketplace

