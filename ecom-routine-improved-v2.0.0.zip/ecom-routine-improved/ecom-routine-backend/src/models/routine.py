from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Routine(db.Model):
    __tablename__ = 'routines'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(100))
    priority = db.Column(db.String(20), default='medium')  # high, medium, low
    marketplace_id = db.Column(db.String(100), db.ForeignKey('marketplaces.id'), nullable=False)
    
    # Periodicity configuration
    frequency = db.Column(db.String(50), nullable=False)  # daily, weekly, monthly, custom
    periodicity_config = db.Column(db.Text)  # JSON string with detailed config
    
    # Execution details
    estimated_time = db.Column(db.Integer)  # in minutes
    responsible = db.Column(db.String(200))
    status = db.Column(db.String(20), default='active')  # active, paused, archived
    
    # Notifications
    notifications_enabled = db.Column(db.Boolean, default=True)
    
    # Next execution
    next_execution = db.Column(db.DateTime)
    last_execution = db.Column(db.DateTime)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships (commented to avoid circular imports)
    # tasks = db.relationship('Task', backref='routine_ref', lazy=True, cascade='all, delete-orphan')
    # routine_tasks = db.relationship('RoutineTask', backref='routine_ref', lazy=True, cascade='all, delete-orphan')
    
    def __init__(self, **kwargs):
        super(Routine, self).__init__(**kwargs)
        if self.periodicity_config and isinstance(self.periodicity_config, dict):
            self.periodicity_config = json.dumps(self.periodicity_config)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'priority': self.priority,
            'marketplace': self.marketplace_id,
            'frequency': self.frequency,
            'periodicityConfig': json.loads(self.periodicity_config) if self.periodicity_config else {},
            'estimatedTime': self.estimated_time,
            'responsible': self.responsible,
            'status': self.status,
            'notificationsEnabled': self.notifications_enabled,
            'nextExecution': self.next_execution.isoformat() if self.next_execution else None,
            'lastExecution': self.last_execution.isoformat() if self.last_execution else None,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None,
            'tasks': len(self.routine_tasks),
            'estimatedTimeFormatted': self.format_estimated_time()
        }
    
    def format_estimated_time(self):
        if not self.estimated_time:
            return "N/A"
        
        hours = self.estimated_time // 60
        minutes = self.estimated_time % 60
        
        if hours > 0:
            return f"{hours}h {minutes}min" if minutes > 0 else f"{hours}h"
        else:
            return f"{minutes}min"
    
    @classmethod
    def create_from_dict(cls, data):
        routine = cls(
            name=data.get('name'),
            description=data.get('description'),
            category=data.get('category'),
            priority=data.get('priority', 'medium'),
            marketplace_id=data.get('marketplace'),
            frequency=data.get('frequency'),
            periodicity_config=json.dumps(data.get('periodicityConfig', {})),
            estimated_time=data.get('estimatedTime'),
            responsible=data.get('responsible'),
            status=data.get('status', 'active'),
            notifications_enabled=data.get('notificationsEnabled', True),
            next_execution=datetime.fromisoformat(data['nextExecution']) if data.get('nextExecution') else None
        )
        return routine


class RoutineTask(db.Model):
    __tablename__ = 'routine_tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    routine_id = db.Column(db.Integer, db.ForeignKey('routines.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    order = db.Column(db.Integer, default=0)
    estimated_time = db.Column(db.Integer)  # in minutes
    required = db.Column(db.Boolean, default=True)
    
    # Task configuration
    task_type = db.Column(db.String(50), default='manual')  # manual, automated, checklist
    configuration = db.Column(db.Text)  # JSON string with task-specific config
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'routineId': self.routine_id,
            'title': self.title,
            'description': self.description,
            'order': self.order,
            'estimatedTime': self.estimated_time,
            'required': self.required,
            'taskType': self.task_type,
            'configuration': json.loads(self.configuration) if self.configuration else {},
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None
        }

